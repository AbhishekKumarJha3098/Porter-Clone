function navbar1(){
    return `
 
   
    
 
 <div id = "options1">
 
         
     <div id = "optl1">
       <div > <a href="../homepage/home.html" id = "a1">CITY TEMPO</a></div>
      
       <div><a href="../packers&movers/index.html" id = "a2">PACERES & MOVERS</a></div>
       <div><a href="../driverpage/driver&Partner.html" id = "a3">DRIVE PARTNERS</a></div>

       <div><a href="../forenterprisepage/forEnterprise.html">FOR ENTERPRISE </a></div>
     </div>
     <div id = "optr1">
      <div id ="support"><a href="">Support</a></div>
      <div ><button data-modal-target="#modalp" id = "order">Track Order</button></div>
     </div>
         
 
     
 
 </div>`
 
 }
 
 export default navbar1