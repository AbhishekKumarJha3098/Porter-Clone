function navbar() {
    return `
 
     <div id = "options">
 
         
     <div id = "optl">
        <div id="portr" style="background-image: url(&quot;https://d35ppnqksufxmo.cloudfront.net/frontend_website/fb288e54f8f9bcd6f987196eff3ef431.svg&quot;);  height: 2rem; width: 15rem;"></div>
      
        <div id = "logorr">India's Largest Marketplace for Intracity Logistics</div>
     </div>
     <div id = "optr">
       <div id = "driverlogo"><img src ="https://d35ppnqksufxmo.cloudfront.net/frontend_website/9e4ccae9c5a1b669d8fa2648db220c3f.svg"></div>
        <div id = "logodiv">
      
           <div id = "drive"><span id = "DI"> DRIVE WITH US </span><span id = "DI1">turn kms into money</span></div>
           <div id = "join">JOIN&nbsp;US</div>
       </div>
       
       <div id = "last">
         
          <div id = "num"><img src = "phone.jpg" style = "height : 25px;width : 25px;" />4410-4410</div>
         <div id = "add">add your city code</div>
       </div>
     </div>
         
 
     
 
 </div>
 
 `

}

export default navbar